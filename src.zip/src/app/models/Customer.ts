export class customerModel{
    public customerId:number;
    public customerName:string;
    public customerGender:String;
    public customerDept:string;
    public customerSalary:number
}