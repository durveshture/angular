import { Injectable } from "@angular/core";
import { customerModel } from "../models/Customer";
import { Router } from "@angular/router";

@Injectable({
  providedIn: "root"
})
export class CustomerService {
  custArray: customerModel[];

  constructor(private routes: Router) {
    this.custArray = [];
  }

  addCustomer(customer: customerModel) {
    customer.customerId = Math.floor(Math.random() * 100);
    this.custArray.push(customer);
    this.routes.navigate(["/display"]);
  }

  deleteCustomer(id: number) {
    this.custArray.splice(id, 1);
  }

  searchCustomer(id: number) {
    var searchedCust = this.custArray.find(x => x.customerId == id);
    if (searchedCust == null) {
      return null;
    } else {
      return searchedCust;
    }
  }

  sortCustomer() {
    return this.custArray.sort((a, b) =>
      a.customerSalary > b.customerSalary
        ? 1
        : a.customerSalary < b.customerSalary
        ? -1
        : 0
    );
  }

  getEmployees() {
    return this.custArray;
  }

  editCustomer(id:number) {
    return this.custArray[id];
    // return this.custArray.find(x => x.customerId == id);
  }
}
