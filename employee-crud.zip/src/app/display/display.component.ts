import { CustomerService } from './../services/customer.service';
import { customerModel } from './../models/Customer';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  custArray:customerModel[];
  isEditing:boolean;
  customerToEdit:customerModel;

  constructor(private custService:CustomerService) {
    this.custArray=[];
   }

  sortCustomer(){
   this.custService.sortCustomer();
  }

  editCustomer(id:number){
    this.isEditing=true;
    this.customerToEdit=this.custService.editCustomer(id);
  }

  deleteCustomer(id:number){
   this.custService.deleteCustomer(id);
  }

  ngOnInit() {
    this.custArray=this.custService.getEmployees();
  }

}
