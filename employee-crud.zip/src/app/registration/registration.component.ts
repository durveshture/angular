import { Component, OnInit, Input, Output ,EventEmitter} from '@angular/core';
import { customerModel } from '../models/Customer';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  @Input() customer:customerModel;
  @Input() isEdited:boolean;
  @Output() edited= new EventEmitter();

  constructor(private custService: CustomerService) {
    this.customer= new customerModel();
   }

   add(){
     this.custService.addCustomer(this.customer);
     this.customer= new customerModel();
   }

   update(){
     this.isEdited=false;
     this.customer= new customerModel();
     this.edited.emit();
   }



  ngOnInit() {
  }

}
