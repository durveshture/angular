/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HelloWorldComponent } from './hello-world.component';

describe('Component: HelloWorld', () => {
  it('should create an instance', () => {
    let component = new HelloWorldComponent();
    expect(component).toBeTruthy();
  });
});
