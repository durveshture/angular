import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayComponent } from './display/display.component';
import { RegisterComponent } from './register/register.component';
import { SearchComponent } from './search/search.component';
import { FormsModule} from '@angular/forms';
import { StudentService } from './service/student.service';

@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    RegisterComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
