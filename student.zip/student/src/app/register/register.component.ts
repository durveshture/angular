import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StudentModel } from '../models/student';
import { StudentService } from '../service/student.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Input() student:StudentModel;

  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();
   
  constructor(private stuService: StudentService) { 
    this.student= new StudentModel();
  }

  addStudent(){
    this.stuService.addStudent(this.student);
    this.student= new StudentModel();
  }

  updateStudent(){
    this.student= new StudentModel();
    this.isEditing=false;
    this.edited.emit();
  }

  ngOnInit() {
  }

}
