import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { StudentModel } from '../models/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  studentDatabase: StudentModel[];

  constructor(private routes: Router) {
    this.studentDatabase = [];
  }

  addStudent(student: StudentModel) {
    student.studentRollNo = Math.floor(Math.random() * 100);
    this.studentDatabase.push(student);
    this.routes.navigate(['/display']);
  }

  deleteStudent(index: number) {
    this.studentDatabase.splice(index, 1);
  }

  editStudent(id: number) {
    return this.studentDatabase.find(a => a.studentRollNo == id);
  }

  getStudents() {
    return this.studentDatabase;
  }

  searchStudent(id: number) {
    var student = this.studentDatabase.find(a => a.studentRollNo == id);
    if (student == null) {
      return null;
    } else {
      return student;
    }
  }

 sortStudent(){
   return this.studentDatabase.sort((a,b)=>a.studentName.localeCompare(b.studentName.valueOf()));
 }
}
