export class StudentModel{
    public studentName: string;
    public studentRollNo: number;
    public  studentMobileNo: number;
    public studentGender: string
}