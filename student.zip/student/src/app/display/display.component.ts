import { Component, OnInit } from '@angular/core';
import { StudentModel } from '../models/student';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  studentDatabase: StudentModel[];
  studentToEdit: StudentModel;
  isEditing: boolean;

  constructor(private stuService: StudentService) {
    this.studentDatabase = [];
    this.studentToEdit = new StudentModel();
  }

  ngOnInit() {
    this.studentDatabase = this.stuService.getStudents();
  }

  sortStudent() {
    this.stuService.sortStudent();
  }

  delete(index: number) {
    this.stuService.deleteStudent(index);
  }

  edit(id: number) {
    this.isEditing = true;
    this.stuService.editStudent(id);
  }
}
