import { Component } from '@angular/core';

@Component({
    selector: "greeting",
    template: `
       <h1>{{message}}</h1>
    `

})

export class GreetComponent{
  message="Welcome to Angular 6"
}