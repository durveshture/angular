import { Component } from '@angular/core';

@Component({
    selector: "login",
    templateUrl: './login.component.html'
})

export class LoginComponent{
    userid:string;
    password:string;
    roles:string[];
    submitted:boolean;
    selected:string;

    constructor(){
        this.roles=['Admin','User','Guest'];
        this.userid="Durvesh"
        this.password="Ture"
    }

    validate(){
        this.submitted=true;
        console.log(this.userid+"="+this.password);
    }
}