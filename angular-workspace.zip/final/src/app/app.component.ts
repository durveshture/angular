import { Component } from '@angular/core';
import { CustomerModel } from './model/Customer';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product';

  customerArr:CustomerModel[];
  customer:CustomerModel;
  id:number;
  
  constructor(){
     this.customerArr = [];
     this.customer = new CustomerModel();
     this.id = 0;
  }

  add()
  {
      this.customer.id = this.customerArr.length+1
      this.customerArr.push(this.customer);
      this.customer = new CustomerModel();
  }

  edit(index:number)
  {
    this.customer = this.customerArr[index];
      this.id = index;
   // this.remove(this.customerArr.findIndex(y=>y.id==this.customer.id));
  }

  update()
  {
      this.customerArr[this.id] = this.customer;
      this.id=0;
      this.customer = new CustomerModel();
  }

  remove(index:number)
  {
     this.customerArr.splice(index,1);
  }

  sort()
  {
      this.customerArr.sort((a,b)=>a.name>b.name?1:a.name<b.name?-1:0);
  }
}
