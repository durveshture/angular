export class EmployeeModel {

    public employeeId: number;
    public employeeName: string;
    public employeeGender: string;
    public employeeDepartment: string;
    public employeeSalary: number;

}