package com.capgemini.xyz.ExceptionClass;

public class InvalidReceiverException extends Exception {

	public InvalidReceiverException() {
		// TODO Auto-generated constructor stub
	}
	
	public InvalidReceiverException(String message) {
		super(message);
	}
}
