package com.capgemini.xyz.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;

public interface InterfaceService {

	// declaring regex for all inputs
	String userNamePattern = "[A-Z][a-z]{2,9}";
	String emailPattern = "^(.+)@(.+)$";
	String mobNoPattern = "(0/91)?[7-9][0-9]{9}";
	String paswordPattern = "(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$";

	// declaring abstract methods
	boolean validateName(String name);

	boolean validateEmail(String email);

	boolean validateMobNo(String mobNo);

	boolean validatePassword(String password);

	String deposit(Customer customer, double amount)
			throws NegativeAmountException, SQLException;

	String withdraw(Customer customer, double amount)
			throws LowBalanceException, SQLException;

	Customer login(long mobNo, String password) throws SQLException, InvalidCredentialsException;

	double showBalance(Customer customer) throws SQLException;

	String insertCustomer(Customer customer, Connection connection) throws SQLException;

	String fundTransfer(Customer senderCustomer, Customer receiverCustomer,
			Double amount) throws SenderReceiverSameException,
			LowBalanceException, NegativeAmountException, SQLException;

	Customer checkUser(long receiverMobNo) throws SQLException, InvalidCredentialsException;

	void printTransaction(long mobNo) throws SQLException;
}
