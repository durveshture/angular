package com.capgemini.xyz.dao;

//import java.util.ArrayList;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Transaction;

public class ClassDao implements InterfaceDao {

	Map<Long, Customer> customerMap = new HashMap<>();
	ArrayList<Transaction> tranArray = new ArrayList<Transaction>();
	Transaction tran;

	// Map<Long,String> loginCustomer= new HashMap<>();
	// ArrayList<Customer> database= new ArrayList<>();

	// deposit money in current customer's mobile no account
	@Override
	public String deposit(Customer customer, double amount)
			throws NegativeAmountException {

		if (amount <= 0) {

			throw new NegativeAmountException(
					"Please enter amount greater than 0");

		} else {
			// customerMap.get(mobNo).setBalance(
			// customerMap.get(mobNo).getBalance() + amount);
			// tran = new Transaction("credit", amount, customerMap.get(mobNo)
			// .getBalance(),customerMap.get(mobNo).getMobileNo());
			// tranArray.add(tran);
			customerMap.get(customer.getMobileNo()).setBalance(
					customerMap.get(customer.getMobileNo()).getBalance()
							+ amount);
			tran = new Transaction("credit", amount, customerMap.get(
					customer.getMobileNo()).getBalance(), customerMap.get(
					customer.getMobileNo()).getMobileNo());
			tranArray.add(tran);
		}
		return "Rs " + amount + " deposited successfully at "
				+ LocalDateTime.now() + " for mobile no: "
				+ customer.getMobileNo() + "\n Your updated balance is: "
				+ showBalance(customer);
	}

	// withdraw money in current customer's mobile no account
	@Override
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException {

		if (amount > customerMap.get(customer.getMobileNo()).getBalance()) {

			throw new LowBalanceException("Your balance is low");

		} else {
			customerMap.get(customer.getMobileNo()).setBalance(
					customerMap.get(customer.getMobileNo()).getBalance()
							- amount);
		}
		tran = new Transaction("debit", amount, customerMap.get(
				customer.getMobileNo()).getBalance(), customerMap.get(
				customer.getMobileNo()).getMobileNo());
		tranArray.add(tran);
		return "Rs " + amount + " withdrawn successfully at "
				+ LocalDateTime.now() + " for mobile no: "
				+ customer.getMobileNo() + "\n Your updated balance is: "
				+ showBalance(customer);
	}

	// checking if the user inputted mobNo and password exists in the map
	@Override
	public Customer login(long mobNo, String password) {

		for (Long key : customerMap.keySet()) {
			if (key == mobNo
					&& customerMap.get(key).getPassword().equals(password)) {
				return customerMap.get(key);
			}
		}
		return null;
	}

	// inserting the customer obj in the map
	@Override
	public String insertCustomer(Customer customer, Connection connection) {

		customerMap.put(customer.getMobileNo(), customer);
		return "Registration successfull! your username is your mobile number: "
				+ customer.getMobileNo();
	}

	// retrieving balance using current customer's mobile no
	@Override
	public double showBalance(Customer customer) {
		return customerMap.get(customer.getMobileNo()).getBalance();

	}

	// transfer amount from one customer obj to other
	@Override
	public String fundTransfer(Customer senderCustomer,
			Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException {
		if (senderCustomer.getMobileNo() == receiverCustomer.getMobileNo()) {

			throw new SenderReceiverSameException("Cannot send to yourself");

		}
		withdraw(senderCustomer, amount); // withdrawing amount from sender's
											// wallet
		deposit(receiverCustomer, amount); // depositing amount to receiver's
											// wallet
		return amount + " Rs transferred to mobile number: "
				+ receiverCustomer.getMobileNo()
				+ "\n Your updated balance is: " + showBalance(senderCustomer);
	}

	@Override
	public Customer checkUser(long receiverMobNo) { // finding the user inputted
													// receiverMobNo in the map
		for (Long key : customerMap.keySet()) {
			if (receiverMobNo == customerMap.get(key).getMobileNo()) {
				return customerMap.get(key);
			}
		}
		return null;
	}

	@Override
	public void printTransaction(long mobNo) {

		for (Transaction t : tranArray) {
			if (t.getMobNo() == mobNo) {
				System.out.println(t.toString());
			}
			// System.out.println(t);
		}
	}
}
