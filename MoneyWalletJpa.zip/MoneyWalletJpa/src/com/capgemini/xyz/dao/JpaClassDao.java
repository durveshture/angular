package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.persistence.EntityManager;

import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.cg.jpacrud.entities.Student;

public class JpaClassDao implements InterfaceDao {

	private EntityManager entityManager;

	public JpaClassDao() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public String deposit(Customer customer, double amount)
			throws NegativeAmountException, SQLException {

		customer.setBalance(customer.getBalance() + amount);
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();

		return "Rs " + amount + " deposited successfully at "
				+ LocalDateTime.now() + " for mobile no: "
				+ customer.getMobileNo() + "\n Your updated balance is: "
				+ showBalance(customer);
	}

	@Override
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException, SQLException {
		
		customer.setBalance(customer.getBalance() - amount);
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		
		return "Rs " + amount + " withdrawn successfully at "
		+ LocalDateTime.now() + " for mobile no: "
		+ customer.getMobileNo() + "\n Your updated balance is: "
		+ showBalance(customer);
	}

	@Override
	public Customer login(long mobNo, String password) throws SQLException,
			InvalidCredentialsException {
		
		Customer cust=entityManager.find(Customer.class,mobNo);
		if(cust!=null){
			return cust;
		}else{
			return null;
		}
		
	}

	@Override
	public String insertCustomer(Customer customer, Connection connection)
			throws SQLException {
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();

		return "Registration successfull! your username is your mobile number: "
				+ customer.getMobileNo();
	}

	@Override
	public double showBalance(Customer customer) throws SQLException {
		Customer cust=entityManager.find(Customer.class,customer.getMobileNo());
		return cust.getBalance();
	}

	@Override
	public String fundTransfer(Customer senderCustomer,
			Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException, SQLException {
		
		senderCustomer.setBalance(senderCustomer.getBalance() - amount);
		entityManager.getTransaction().begin();
		entityManager.persist(senderCustomer);
		entityManager.getTransaction().commit();
		
		receiverCustomer.setBalance(receiverCustomer.getBalance() + amount);
		entityManager.getTransaction().begin();
		entityManager.persist(receiverCustomer);
		entityManager.getTransaction().commit();
		
		return amount + " Rs transferred to mobile number: "
		+ receiverCustomer.getMobileNo()
		+ "\n Your updated balance is: " + showBalance(senderCustomer);
	}

	@Override
	public Customer checkUser(long receiverMobNo) throws SQLException,
			InvalidCredentialsException {
		
		
		return null;
	}

	@Override
	public void printTransaction(long mobNo) throws SQLException {
		// TODO Auto-generated method stub

	}

}
