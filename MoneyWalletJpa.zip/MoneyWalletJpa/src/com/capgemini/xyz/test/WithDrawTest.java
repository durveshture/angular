package com.capgemini.xyz.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.ClassService;
import com.capgemini.xyz.service.InterfaceService;


public class WithDrawTest {
	InterfaceService service = null;

	@Before
	public void setUp() throws Exception {
		service = new ClassService();
	}

	// right inputs
	@Test
	public void checkWithDraw() throws LowBalanceException, SQLException {
		
			Customer customer = new Customer("durvesh", "t@g.c",4000, 8286703935L,56,
					"password");
			Connection conn = null;
			service.insertCustomer(customer,conn);

			String result = service.withdraw(customer, 2000);
			assertNotNull(result);
		
	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkWithDraw2() throws SQLException, InvalidCredentialsException, LowBalanceException {
	
		Customer customer = new Customer("durvesh", "t@g.c",4000, 8286703935L,56,
				"password");
		Connection conn = null;
			service.insertCustomer(customer,conn);
			service.checkUser(customer.getMobileNo());

			String result = service.withdraw(customer, 9000);
			assertNotNull(result);
		
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
