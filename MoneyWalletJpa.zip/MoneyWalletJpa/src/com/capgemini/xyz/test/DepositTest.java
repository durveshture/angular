package com.capgemini.xyz.test;



import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.ClassService;
import com.capgemini.xyz.service.InterfaceService;

public class DepositTest {
	InterfaceService service = null;

	@Before
	public void setUp() throws Exception {
		service = new ClassService();
	}

	// right inputs
	@Test
	public void checkDeposit() throws SQLException {
		
			Customer customer = new Customer("durvesh", "t@g.c",4000, 8286703935L,56,
					"password");
			try {
				service.insertCustomer(customer, null);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			String result;
			try {
				result = service.deposit(customer, 2000);
				assertNotNull(result);
			} catch (NegativeAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	// wrong inputs
	// should print no user as user don't exists in console
	@Test
	public void checkDeposit2() throws SQLException {
	
			Customer customer = new Customer();
			try {
				service.insertCustomer(customer, null);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
//			service.checkUser(customer.getMobileNo());
			String result;
			try {
				result = service.deposit(customer, 9000);
				assertNotNull(result);
			} catch (NegativeAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
