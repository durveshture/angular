package com.capgemini.xyz.test;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.ExceptionClass.CustomerExistsException;
import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.ClassService;
import com.capgemini.xyz.service.InterfaceService;

public class LoginTest {

	InterfaceService service = null;

	@Before
	public void setUp() throws Exception {
		service = new ClassService();
	}

	//right inputs
	@Test
	public void checkLogin() throws SQLException, InvalidCredentialsException {
			Customer customer = new Customer("Tushar", "t@g.c",4000, 8286703935L,56,
					"password");
			try {
				service.insertCustomer(customer, null);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Customer cust = service.login(8286703935L,"password");
			assertNotNull(cust);
		
	}

	//wrong inputs
	// should print no user in console
	@Test
	public void checkLogin2() throws SQLException, InvalidCredentialsException {
		Customer customer = new Customer("Tushar", "t@g.c",4000, 8286703935L,56,
				"password");
		try {
			service.insertCustomer(customer, null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Customer cust = service.login(8452802158L,"jnygtj");
		assertNotNull(cust);
	}	
	@After
	public void destroy() throws Exception {
		service = null;
	}
}
