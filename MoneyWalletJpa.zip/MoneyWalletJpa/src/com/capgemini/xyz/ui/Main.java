package com.capgemini.xyz.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.xyz.ExceptionClass.CustomerExistsException;
import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.InvalidReceiverException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.config.JdbcConfig;
import com.capgemini.xyz.service.ClassService;
import com.capgemini.xyz.service.InterfaceService;

public class Main {
	
	 

	public static void main(String[] args) throws Exception {
//		System.out.println("hi");
		Scanner sc = new Scanner(System.in);
		String choice, password, currentLoginPassword, email, mobNo, currentLoginMobNo;
		boolean isValid, isLogout = false;
		Customer validatedUser, validatedReceiver, customerExists;
		double custId = 1;
		String messageToDisplay;
		Connection connection=null;
	
		InterfaceService is = new ClassService();
//			connection= JdbcConfig.getConnection();
//			InterfaceService is = new ClassService(connection);
		
		 // creating service class
													// object
		Customer customer; // declaring customer bean object
		
		

		for (;;) {
			// Home page
			System.out.println("Weclcome to DTM wallet");
			System.out.println("1) Register");
			System.out.println("2) Login");
			choice = sc.next();
			if (choice.equals("1")) {
				customer = new Customer(); // creating a new customer obj if
											// user selects register option
				while (true) {
					// Registration page
					System.out.println("Enter Name: "); // input name and
														// validate regex
					String name = sc.next();
					isValid = is.validateName(name);
					if (isValid) {
						customer.setName(name); // if name is valid,populate the
												// customer obj
						break;
					}
					System.out
							.println("Name should contain only alphabets & first letter should be capital");
				}
				while (true) {
					System.out.println("Enter Mobile Number: "); // input mob no
																	// and
																	// validate

					mobNo = sc.next();
					isValid = is.validateMobNo(mobNo);
					if (isValid) {
						customer.setMobileNo(Long.parseLong(mobNo)); // if mobno
																		// is
																		// valid,populate
																		// the
																		// customer
																		// obj
						break;
					}
					System.out
							.println("Mobile number should be 10 digits and start with 7/8/9");
				}
				while (true) {
					System.out.println("Enter password: "); // input password
															// and validate

					password = sc.next();
					isValid = is.validatePassword(password);
					if (isValid) {
						customer.setPassword(password); // if password is
														// valid,populate the
														// customer obj
						break;
					}
					System.out
							.println("Password should be 8 characters, should contain at least one special character, digit and one uppercase letter");
				}
				while (true) {
					System.out.println("Enter Email Id: "); // input email and
															// validate
					email = sc.next();
					isValid = is.validateEmail(email);
					if (isValid) {
						customer.setEmail(email); // if email is valid,populate
													// the customer obj
						break;
					}
					System.out.println("Invalid email");
				}

				customerExists = is.checkUser(Long.parseLong(mobNo));
				if (customerExists != null) {
					try {
						throw new CustomerExistsException(
								"There is already an account for this mobile number");
					} catch (CustomerExistsException e) {
						e.printStackTrace();
					}
				}
				customer.setCustId(custId);
				custId++;
				try {
					is.insertCustomer(customer, connection);
					System.out.println("Registration successfull!!");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {
				// login page
				while (true) {
					System.out.println("Enter Mobile Number: "); // input mob no
																	// and
																	// validate

					currentLoginMobNo = sc.next();
					isValid = is.validateMobNo(currentLoginMobNo);
					if (isValid) {
						break;
					}
				}
				while (true) {
					System.out.println("Enter password: "); // input password
															// and validate

					currentLoginPassword = sc.next();
					isValid = is.validatePassword(currentLoginPassword);
					if (isValid) {
						break;
					}
				}
				validatedUser = is.login(Long.parseLong(currentLoginMobNo), // user
																			// login
																			// validation
						currentLoginPassword);

				if (validatedUser != null) { // if mobno and password is
												// correct,login successfull and
												// welcome page is displayed
					// Menu(welcome) page
					// Menu page has total 6 functionalities
					System.out.println("Welcome");
					while (true) {
						System.out.println("1) Show Balance");
						System.out.println("2) Deposit");
						System.out.println("3) Withdraw");
						System.out.println("4) Fund Transfer");
						System.out.println("5) Print Transactions");
						System.out.println("6) Log out");
						choice = sc.next();

						switch (choice) {

						case "1": // to show balance of current login person
							System.out.println("Your balance is: "
									+ is.showBalance(validatedUser));
							break;

						case "2": // to deposit money of curent login customer
							System.out
									.println("How much amount you want to deposit?");
							double amount = sc.nextDouble();

							try {
								messageToDisplay = is.deposit(validatedUser,
										amount);
								System.out.println(messageToDisplay);
							} catch (NumberFormatException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (NegativeAmountException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							// System.out.println("Your updated balance is: "
							// + is.showBalance(Long
							// .parseLong(currentLoginMobNo)));
							break;

						case "3": // to withdraw money of current login customer
							System.out
									.println("How much amount you want to withdraw?");
							amount = sc.nextDouble();

							try {
								messageToDisplay = is.withdraw(validatedUser,
										amount);
								System.out.println(messageToDisplay);
							} catch (NumberFormatException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (LowBalanceException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							// System.out.println("Your updated balance is: "
							// + is.showBalance(Long
							// .parseLong(currentLoginMobNo)));
							break;

						case "4": // to transfer money from one customer object
									// to other
							System.out
									.println("Enter the mobile number of receiver: ");
							long receiverMobNo = sc.nextLong();
							validatedReceiver = is.checkUser(receiverMobNo);
							if (validatedReceiver != null) {
								System.out.println("Enter the amount: ");
								double transferAmount = sc.nextDouble();

								try {
									messageToDisplay = is.fundTransfer(
											validatedUser, validatedReceiver,
											transferAmount);
									System.out.println(messageToDisplay);
								} catch (NumberFormatException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (SenderReceiverSameException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (LowBalanceException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (NegativeAmountException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							} else {
								try {
									throw new InvalidReceiverException(
											"Invalid mobile number of receiver");
								} catch (InvalidReceiverException e) {
									e.printStackTrace();
								}
							}
							break;

						case "5": // to print transaction statement of current
									// login customer
							is.printTransaction(Long
									.parseLong(currentLoginMobNo));
							break;

						case "6": // to logout
							isLogout = true;
							break;

						default: // if user selects option which is not in menu,
									// throw exception
							System.out.println("Enter a valid choice");
						}
						if (isLogout == true) { // if user selects logout
												// option, break the infinite
												// while loop
							isLogout = false;
							break;
						} else {
							continue;
						}
					}

				} else {
					try {
						throw new InvalidCredentialsException(
								"Invalid username or password"); // if username
																	// or
																	// password
																	// is
																	// incorrect
																	// during
																	// login,
																	// throw an
																	// exception
					} catch (InvalidCredentialsException e) {
						System.out.println(e.getMessage());
//						e.printStackTrace();
					}
				}

			}
		}
	}
}